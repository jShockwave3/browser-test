import { apiRequest } from "./queryClient";
import type { ProxyResponse } from "@shared/schema";

export interface ProxyApiResponse {
  success: boolean;
  data?: ProxyResponse;
  error?: string;
}

export async function fetchProxyContent(url: string): Promise<ProxyApiResponse> {
  try {
    const response = await apiRequest("POST", "/api/proxy", { url });
    return await response.json();
  } catch (error: any) {
    return {
      success: false,
      error: error.message || "Failed to fetch content through proxy",
    };
  }
}

export async function getProxyRequest(id: number): Promise<ProxyApiResponse> {
  try {
    const response = await apiRequest("GET", `/api/proxy/${id}`);
    return await response.json();
  } catch (error: any) {
    return {
      success: false,
      error: error.message || "Failed to get proxy request status",
    };
  }
}

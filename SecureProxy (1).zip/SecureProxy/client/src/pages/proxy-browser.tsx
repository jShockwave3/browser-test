import { useState, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { BrowserHeader } from "@/components/browser-header";
import { BrowserContent } from "@/components/browser-content";
import { fetchProxyContent } from "@/lib/proxy-api";
import { useToast } from "@/hooks/use-toast";

interface HistoryEntry {
  url: string;
  content?: string;
  responseTime?: number;
}

export default function ProxyBrowser() {
  const [currentUrl, setCurrentUrl] = useState("");
  const [content, setContent] = useState<string>("");
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [state, setState] = useState<'welcome' | 'loading' | 'content' | 'error'>('welcome');
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [responseTime, setResponseTime] = useState<number | undefined>();
  const { toast } = useToast();

  const proxyMutation = useMutation({
    mutationFn: fetchProxyContent,
    onMutate: () => {
      setState('loading');
      setErrorMessage("");
    },
    onSuccess: (response) => {
      if (response.success && response.data) {
        const { content: htmlContent, responseTime: resTime, url } = response.data;
        
        setContent(htmlContent || "");
        setCurrentUrl(url);
        setResponseTime(resTime);
        setState('content');
        
        // Update history
        const newEntry: HistoryEntry = {
          url,
          content: htmlContent,
          responseTime: resTime,
        };
        
        // Remove any forward history if we're not at the end
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newEntry);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        
        toast({
          title: "Page loaded successfully",
          description: `Loaded ${url} in ${resTime}ms`,
        });
      } else {
        setErrorMessage(response.error || "Failed to load page");
        setState('error');
        toast({
          variant: "destructive",
          title: "Failed to load page",
          description: response.error,
        });
      }
    },
    onError: (error: any) => {
      setErrorMessage(error.message || "Network error occurred");
      setState('error');
      toast({
        variant: "destructive",
        title: "Network error",
        description: error.message,
      });
    },
  });

  const validateAndFormatUrl = (url: string): string => {
    const trimmed = url.trim();
    if (!trimmed) return "";
    
    // Add protocol if missing
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      return `https://${trimmed}`;
    }
    
    return trimmed;
  };

  const handleUrlSubmit = useCallback((url: string) => {
    const formattedUrl = validateAndFormatUrl(url);
    if (!formattedUrl) {
      toast({
        variant: "destructive",
        title: "Invalid URL",
        description: "Please enter a valid URL",
      });
      return;
    }

    try {
      new URL(formattedUrl); // Validate URL format
      proxyMutation.mutate(formattedUrl);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Invalid URL",
        description: "Please enter a valid URL",
      });
    }
  }, [proxyMutation, toast]);

  const handleBack = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const entry = history[newIndex];
      setHistoryIndex(newIndex);
      setCurrentUrl(entry.url);
      setContent(entry.content || "");
      setResponseTime(entry.responseTime);
      setState('content');
    }
  }, [history, historyIndex]);

  const handleForward = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const entry = history[newIndex];
      setHistoryIndex(newIndex);
      setCurrentUrl(entry.url);
      setContent(entry.content || "");
      setResponseTime(entry.responseTime);
      setState('content');
    }
  }, [history, historyIndex]);

  const handleRefresh = useCallback(() => {
    if (currentUrl) {
      proxyMutation.mutate(currentUrl);
    }
  }, [currentUrl, proxyMutation]);

  const handleLoadExample = useCallback((url: string) => {
    handleUrlSubmit(url);
  }, [handleUrlSubmit]);

  const handleRetry = useCallback(() => {
    if (currentUrl) {
      proxyMutation.mutate(currentUrl);
    }
  }, [currentUrl, proxyMutation]);

  const handleGoHome = useCallback(() => {
    setCurrentUrl("");
    setContent("");
    setErrorMessage("");
    setResponseTime(undefined);
    setState('welcome');
  }, []);

  const canGoBack = historyIndex > 0;
  const canGoForward = historyIndex < history.length - 1;
  const isLoading = proxyMutation.isPending;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <BrowserHeader
        currentUrl={currentUrl}
        onUrlSubmit={handleUrlSubmit}
        onBack={handleBack}
        onForward={handleForward}
        onRefresh={handleRefresh}
        canGoBack={canGoBack}
        canGoForward={canGoForward}
        isLoading={isLoading}
      />
      
      <BrowserContent
        state={state}
        content={content}
        currentUrl={currentUrl}
        errorMessage={errorMessage}
        responseTime={responseTime}
        onLoadExample={handleLoadExample}
        onRetry={handleRetry}
        onGoHome={handleGoHome}
      />
      
      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between text-sm text-slate-500 space-y-2 sm:space-y-0">
            <div className="flex items-center space-x-4">
              <span>ProxyBrowse v1.0</span>
              <span className="hidden sm:inline">•</span>
              <span className="flex items-center space-x-1">
                <span>Server: Online</span>
              </span>
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="hover:text-slate-700 transition-colors">Privacy Policy</button>
              <span className="hidden sm:inline">•</span>
              <button className="hover:text-slate-700 transition-colors">Help</button>
              <span className="hidden sm:inline">•</span>
              <button className="hover:text-slate-700 transition-colors">About</button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, ArrowRight, RefreshCw, Globe, Settings, Menu, Lock, ArrowRight as ArrowRightIcon } from "lucide-react";

interface BrowserHeaderProps {
  currentUrl: string;
  onUrlSubmit: (url: string) => void;
  onBack: () => void;
  onForward: () => void;
  onRefresh: () => void;
  canGoBack: boolean;
  canGoForward: boolean;
  isLoading: boolean;
}

export function BrowserHeader({
  currentUrl,
  onUrlSubmit,
  onBack,
  onForward,
  onRefresh,
  canGoBack,
  canGoForward,
  isLoading,
}: BrowserHeaderProps) {
  const [urlInput, setUrlInput] = useState(currentUrl);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (urlInput.trim()) {
      onUrlSubmit(urlInput.trim());
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleUrlSubmit(e);
    }
  };

  const isSecureUrl = currentUrl.startsWith('https://');

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Globe className="h-6 w-6 text-blue-600" />
              <h1 className="text-xl font-semibold text-slate-800 hidden sm:block">ProxyBrowse</h1>
            </div>
          </div>

          {/* Navigation Controls and URL Bar */}
          <div className="flex-1 max-w-4xl mx-4 sm:mx-8">
            <div className="flex items-center space-x-2 sm:space-x-4">
              {/* Navigation Buttons */}
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onBack}
                  disabled={!canGoBack}
                  className="h-8 w-8 text-slate-600 hover:text-slate-800"
                  title="Go Back"
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onForward}
                  disabled={!canGoForward}
                  className="h-8 w-8 text-slate-600 hover:text-slate-800"
                  title="Go Forward"
                >
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onRefresh}
                  className="h-8 w-8 text-slate-600 hover:text-slate-800"
                  title="Refresh"
                >
                  <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                </Button>
              </div>

              {/* URL Input Bar */}
              <form onSubmit={handleUrlSubmit} className="flex-1 relative">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className={`h-4 w-4 ${isSecureUrl ? 'text-green-500' : 'text-slate-400'}`} />
                  </div>
                  <Input
                    ref={inputRef}
                    type="url"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Enter URL to browse through proxy..."
                    className="pl-10 pr-12 py-2.5 border-slate-300 bg-slate-50 text-slate-800 text-sm font-mono focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <Button
                      type="submit"
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-blue-600 hover:text-blue-700"
                      title="Navigate"
                    >
                      <ArrowRightIcon className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </form>
            </div>
          </div>

          {/* Additional Controls */}
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-slate-600 hover:text-slate-800"
              title="Settings"
            >
              <Settings className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-slate-600 hover:text-slate-800 sm:hidden"
              title="Menu"
            >
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Loading Bar */}
      {isLoading && (
        <div className="h-1 bg-slate-100 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-blue-500 to-blue-600 animate-pulse w-3/5" />
        </div>
      )}
    </header>
  );
}

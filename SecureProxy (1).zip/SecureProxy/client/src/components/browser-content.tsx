import { Button } from "@/components/ui/button";
import { AlertTriangle, Globe, Home, RotateCcw, Shield, Zap, Smartphone, Newspaper, Github, Book } from "lucide-react";
import { Card } from "@/components/ui/card";

interface BrowserContentProps {
  state: 'welcome' | 'loading' | 'content' | 'error';
  content?: string;
  currentUrl?: string;
  errorMessage?: string;
  responseTime?: number;
  onLoadExample: (url: string) => void;
  onRetry: () => void;
  onGoHome: () => void;
}

export function BrowserContent({
  state,
  content,
  currentUrl,
  errorMessage,
  responseTime,
  onLoadExample,
  onRetry,
  onGoHome,
}: BrowserContentProps) {
  const isSecure = currentUrl?.startsWith('https://');

  // Status Bar
  const StatusBar = () => (
    <div className="bg-slate-100 border-b border-slate-200 px-4 py-2 text-sm text-slate-600">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <span>Ready to browse • Proxy server: Active</span>
        <div className="flex items-center space-x-4">
          <span className="flex items-center space-x-1">
            <Shield className="h-3 w-3 text-green-500" />
            <span>Secure Connection</span>
          </span>
          {responseTime && (
            <span>Response: {responseTime}ms</span>
          )}
        </div>
      </div>
    </div>
  );

  const WelcomeScreen = () => (
    <div className="max-w-4xl mx-auto px-4 py-16 text-center">
      <div className="space-y-8">
        <div className="space-y-4">
          <Globe className="h-24 w-24 text-blue-500 opacity-75 mx-auto" />
          <h2 className="text-3xl font-semibold text-slate-800">Welcome to ProxyBrowse</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Enter any URL in the address bar above to browse websites securely through our proxy server. 
            Perfect for accessing content while maintaining privacy and bypassing restrictions.
          </p>
        </div>

        {/* Quick Start Examples */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-12">
          <Card 
            className="p-6 hover:shadow-md transition-all text-left group cursor-pointer border-slate-200 hover:border-blue-300"
            onClick={() => onLoadExample('https://news.ycombinator.com')}
          >
            <div className="flex items-center space-x-3">
              <Newspaper className="h-8 w-8 text-orange-500 group-hover:text-orange-600" />
              <div>
                <h3 className="font-medium text-slate-800">Hacker News</h3>
                <p className="text-sm text-slate-500">Tech news & discussions</p>
              </div>
            </div>
          </Card>

          <Card 
            className="p-6 hover:shadow-md transition-all text-left group cursor-pointer border-slate-200 hover:border-blue-300"
            onClick={() => onLoadExample('https://example.com')}
          >
            <div className="flex items-center space-x-3">
              <Globe className="h-8 w-8 text-blue-500 group-hover:text-blue-600" />
              <div>
                <h3 className="font-medium text-slate-800">Example.com</h3>
                <p className="text-sm text-slate-500">Simple test page</p>
              </div>
            </div>
          </Card>

          <Card 
            className="p-6 hover:shadow-md transition-all text-left group cursor-pointer border-slate-200 hover:border-blue-300"
            onClick={() => onLoadExample('https://wikipedia.org')}
          >
            <div className="flex items-center space-x-3">
              <Book className="h-8 w-8 text-blue-500 group-hover:text-blue-600" />
              <div>
                <h3 className="font-medium text-slate-800">Wikipedia</h3>
                <p className="text-sm text-slate-500">Free encyclopedia</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Important Notice */}
        <div className="mt-12 p-6 bg-yellow-50 border border-yellow-200 rounded-lg text-left max-w-2xl mx-auto">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-medium text-yellow-800">Important Notice</h3>
              <p className="text-sm text-yellow-700 mt-1">
                Some websites (like Discord, GitHub login pages, banking sites) use security measures that prevent them from loading in proxies. 
                These sites may show "refused to connect" errors or not function properly.
              </p>
            </div>
          </div>
        </div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 text-left">
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0">
              <Shield className="h-6 w-6 text-green-500" />
            </div>
            <div>
              <h3 className="font-medium text-slate-800">Secure Browsing</h3>
              <p className="text-sm text-slate-600 mt-1">All traffic is routed through secure proxy servers to protect your privacy.</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0">
              <Zap className="h-6 w-6 text-yellow-500" />
            </div>
            <div>
              <h3 className="font-medium text-slate-800">Fast Performance</h3>
              <p className="text-sm text-slate-600 mt-1">Optimized proxy servers ensure minimal latency and quick page loads.</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0">
              <Smartphone className="h-6 w-6 text-blue-500" />
            </div>
            <div>
              <h3 className="font-medium text-slate-800">Mobile Friendly</h3>
              <p className="text-sm text-slate-600 mt-1">Responsive design works perfectly on all devices and screen sizes.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const LoadingScreen = () => (
    <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <p className="text-slate-600">Loading content through proxy...</p>
        {currentUrl && (
          <div className="text-sm text-slate-500">{currentUrl}</div>
        )}
      </div>
    </div>
  );

  const ErrorScreen = () => (
    <div className="max-w-2xl mx-auto px-4 py-16 text-center">
      <div className="space-y-6">
        <AlertTriangle className="h-24 w-24 text-red-400 mx-auto" />
        <div className="space-y-2">
          <h2 className="text-2xl font-semibold text-slate-800">Unable to Load Page</h2>
          <p className="text-slate-600">
            {errorMessage || "The requested URL could not be loaded through the proxy. This might be due to network issues, invalid URL, or the target site blocking proxy requests."}
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button onClick={onRetry} className="bg-blue-600 hover:bg-blue-700">
            <RotateCcw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
          <Button variant="outline" onClick={onGoHome}>
            <Home className="h-4 w-4 mr-2" />
            Go Home
          </Button>
        </div>
      </div>
    </div>
  );

  const ContentFrame = () => (
    <div className="w-full">
      <iframe
        srcDoc={content}
        className="w-full border-0"
        style={{ height: 'calc(100vh - 120px)' }}
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-top-navigation"
        title="Proxied Content"
      />
    </div>
  );

  return (
    <main className="flex-1 relative">
      <StatusBar />
      
      <div className="relative min-h-screen bg-white">
        {state === 'welcome' && <WelcomeScreen />}
        {state === 'content' && content && <ContentFrame />}
        {state === 'error' && <ErrorScreen />}
        {state === 'loading' && <LoadingScreen />}
      </div>
    </main>
  );
}

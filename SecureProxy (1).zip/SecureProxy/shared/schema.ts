import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const proxyRequests = pgTable("proxy_requests", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  status: text("status").notNull(), // 'success', 'error', 'loading'
  content: text("content"),
  errorMessage: text("error_message"),
  responseTime: integer("response_time"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProxyRequestSchema = createInsertSchema(proxyRequests).pick({
  url: true,
});

export const proxyResponseSchema = z.object({
  id: z.number(),
  url: z.string(),
  status: z.enum(['success', 'error', 'loading']),
  content: z.string().optional(),
  errorMessage: z.string().optional(),
  responseTime: z.number().optional(),
});

export type InsertProxyRequest = z.infer<typeof insertProxyRequestSchema>;
export type ProxyRequest = typeof proxyRequests.$inferSelect;
export type ProxyResponse = z.infer<typeof proxyResponseSchema>;

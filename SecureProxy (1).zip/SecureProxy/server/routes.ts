import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProxyRequestSchema } from "@shared/schema";
import { z } from "zod";
import axios from "axios";
import * as cheerio from "cheerio";

export async function registerRoutes(app: Express): Promise<Server> {
  // Proxy content endpoint
  app.post("/api/proxy", async (req, res) => {
    try {
      const { url } = insertProxyRequestSchema.parse(req.body);
      
      // Validate URL format
      let targetUrl: URL;
      try {
        targetUrl = new URL(url.startsWith('http') ? url : `https://${url}`);
        if (targetUrl.protocol !== 'http:' && targetUrl.protocol !== 'https:') {
          throw new Error('Invalid protocol');
        }
      } catch (error) {
        return res.status(400).json({
          success: false,
          error: "Invalid URL format. Please provide a valid HTTP or HTTPS URL.",
        });
      }

      // Create proxy request record
      const proxyRequest = await storage.createProxyRequest({ url: targetUrl.href });
      
      const startTime = Date.now();
      
      try {
        // Fetch the external content
        const response = await axios.get(targetUrl.href, {
          timeout: 10000,
          headers: {
            'User-Agent': 'ProxyBrowse/1.0 (Proxy Browser)',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          },
          validateStatus: (status) => status < 500, // Accept 4xx errors but not 5xx
        });

        const responseTime = Date.now() - startTime;
        
        let content = response.data;
        
        // Check for frame-busting headers
        const frameOptions = response.headers['x-frame-options'];
        const csp = response.headers['content-security-policy'];
        const isFrameBlocked = frameOptions || (csp && (csp.includes('frame-ancestors') || csp.includes("frame-src 'none'")));

        // Parse and rewrite HTML content
        if (response.headers['content-type']?.includes('text/html')) {
          const $ = cheerio.load(content);
          
          // Remove frame-busting scripts and headers
          $('script').each((_, el) => {
            const scriptContent = $(el).html();
            if (scriptContent && (scriptContent.includes('top.location') || scriptContent.includes('parent.location') || scriptContent.includes('frameElement'))) {
              $(el).remove();
            }
          });
          
          // Rewrite relative URLs to absolute URLs
          const baseUrl = targetUrl.origin;
          
          // Rewrite href attributes
          $('a[href]').each((_, el) => {
            const href = $(el).attr('href');
            if (href && !href.startsWith('http') && !href.startsWith('//') && !href.startsWith('#')) {
              const absoluteUrl = new URL(href, targetUrl.href).href;
              $(el).attr('href', `/api/proxy?url=${encodeURIComponent(absoluteUrl)}`);
            }
          });
          
          // Rewrite src attributes for images, scripts, etc.
          $('img[src], script[src], link[href]').each((_, el) => {
            const src = $(el).attr('src') || $(el).attr('href');
            if (src && !src.startsWith('http') && !src.startsWith('//')) {
              const absoluteUrl = new URL(src, targetUrl.href).href;
              if ($(el).attr('src')) {
                $(el).attr('src', absoluteUrl);
              } else {
                $(el).attr('href', absoluteUrl);
              }
            }
          });
          
          // Add base tag to handle remaining relative URLs
          if ($('base').length === 0) {
            $('head').prepend(`<base href="${baseUrl}/">`);
          }
          
          // Add proxy browser styles and frame-busting prevention
          $('head').append(`
            <style>
              body { margin: 0 !important; }
              * { box-sizing: border-box; }
            </style>
            <script>
              // Prevent frame-busting
              if (window.top !== window.self) {
                window.top = window.self;
              }
            </script>
          `);
          
          content = $.html();

          // Add warning for potentially frame-blocked sites
          if (isFrameBlocked) {
            content = `
              <div style="background: #fef3cd; border: 1px solid #ffeaa7; padding: 12px; margin: 8px; border-radius: 4px; font-family: Arial, sans-serif;">
                <strong>⚠️ Security Notice:</strong> This website may have restrictions that prevent it from loading properly in a proxy. 
                Some features might not work as expected.
              </div>
            ` + content;
          }
        }

        // Update the proxy request with success
        await storage.updateProxyRequest(proxyRequest.id, {
          status: 'success',
          content,
          responseTime,
        });

        res.json({
          success: true,
          data: {
            id: proxyRequest.id,
            url: targetUrl.href,
            content,
            responseTime,
            status: 'success',
          },
        });

      } catch (error: any) {
        const responseTime = Date.now() - startTime;
        const errorMessage = error.response?.status === 404 
          ? "Page not found (404)" 
          : error.code === 'ENOTFOUND' 
          ? "Domain not found. Please check the URL and try again."
          : error.code === 'ECONNREFUSED'
          ? "Connection refused by the target server."
          : error.message || "Failed to fetch the requested page.";

        // Update the proxy request with error
        await storage.updateProxyRequest(proxyRequest.id, {
          status: 'error',
          errorMessage,
          responseTime,
        });

        res.status(error.response?.status || 500).json({
          success: false,
          error: errorMessage,
          data: {
            id: proxyRequest.id,
            url: targetUrl.href,
            status: 'error',
            errorMessage,
            responseTime,
          },
        });
      }

    } catch (error: any) {
      console.error('Proxy request error:', error);
      res.status(400).json({
        success: false,
        error: error.message || "Invalid request",
      });
    }
  });

  // Get proxy request status
  app.get("/api/proxy/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const proxyRequest = await storage.getProxyRequest(id);
      
      if (!proxyRequest) {
        return res.status(404).json({
          success: false,
          error: "Proxy request not found",
        });
      }

      res.json({
        success: true,
        data: proxyRequest,
      });

    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || "Failed to get proxy request",
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

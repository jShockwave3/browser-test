import { proxyRequests, type ProxyRequest, type InsertProxyRequest } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<any | undefined>;
  getUserByUsername(username: string): Promise<any | undefined>;
  createUser(user: any): Promise<any>;
  createProxyRequest(request: InsertProxyRequest): Promise<ProxyRequest>;
  getProxyRequest(id: number): Promise<ProxyRequest | undefined>;
  updateProxyRequest(id: number, updates: Partial<ProxyRequest>): Promise<ProxyRequest | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, any>;
  private proxyRequests: Map<number, ProxyRequest>;
  currentUserId: number;
  currentProxyId: number;

  constructor() {
    this.users = new Map();
    this.proxyRequests = new Map();
    this.currentUserId = 1;
    this.currentProxyId = 1;
  }

  async getUser(id: number): Promise<any | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<any | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: any): Promise<any> {
    const id = this.currentUserId++;
    const user: any = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createProxyRequest(insertRequest: InsertProxyRequest): Promise<ProxyRequest> {
    const id = this.currentProxyId++;
    const request: ProxyRequest = {
      ...insertRequest,
      id,
      status: 'loading',
      content: null,
      errorMessage: null,
      responseTime: null,
      createdAt: new Date(),
    };
    this.proxyRequests.set(id, request);
    return request;
  }

  async getProxyRequest(id: number): Promise<ProxyRequest | undefined> {
    return this.proxyRequests.get(id);
  }

  async updateProxyRequest(id: number, updates: Partial<ProxyRequest>): Promise<ProxyRequest | undefined> {
    const existing = this.proxyRequests.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.proxyRequests.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
